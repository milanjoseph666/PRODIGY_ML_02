
# K-Means Customer Segmentation

This project implements K-means clustering to segment customers of a retail store based on their Annual Income and Spending Score.

## How to Run
1. Download the dataset from Kaggle: https://www.kaggle.com/datasets/vjchoudhary7/customer-segmentation-tutorial-in-python
2. Place `Mall_Customers.csv` inside the `data` folder.
3. Run `kmeans_customer_segmentation.py` using Python.

## Requirements
- pandas
- matplotlib
- seaborn
- scikit-learn
